<?php
define('SITE_TITLE','7Task Project');
define('BASE_URL','http://localhost/7Learn.php/7Todo/');
define('BASE_PATH','C:/xampp/htdocs/7Learn.php/7Todo/');

