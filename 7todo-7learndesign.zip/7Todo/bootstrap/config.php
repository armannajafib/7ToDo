<?php
$database_config = (object)[
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'db' => '7todo'
];